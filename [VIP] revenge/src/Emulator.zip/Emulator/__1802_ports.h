#ifndef INPORT1
#define INPORT1() (0)
#endif
#ifndef OUTPORT1
#define OUTPORT1(v) {}
#endif
#ifndef INPORT2
#define INPORT2() (0)
#endif
#ifndef OUTPORT2
#define OUTPORT2(v) {}
#endif
#ifndef INPORT3
#define INPORT3() (0)
#endif
#ifndef OUTPORT3
#define OUTPORT3(v) {}
#endif
#ifndef INPORT4
#define INPORT4() (0)
#endif
#ifndef OUTPORT4
#define OUTPORT4(v) {}
#endif
#ifndef INPORT5
#define INPORT5() (0)
#endif
#ifndef OUTPORT5
#define OUTPORT5(v) {}
#endif
#ifndef INPORT6
#define INPORT6() (0)
#endif
#ifndef OUTPORT6
#define OUTPORT6(v) {}
#endif
#ifndef INPORT7
#define INPORT7() (0)
#endif
#ifndef OUTPORT7
#define OUTPORT7(v) {}
#endif
#ifndef EFLAG1
#define EFLAG1() (0)
#endif
#ifndef EFLAG2
#define EFLAG2() (0)
#endif
#ifndef EFLAG3
#define EFLAG3() (0)
#endif
#ifndef EFLAG4
#define EFLAG4() (0)
#endif
#ifndef OUTPORTQ
#define OUTPORTQ(old,new) {}
#endif
